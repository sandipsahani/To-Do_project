import React from 'react';
import "./Home.css"
const Home = () => {
  return (
    <div>
      <h1>Welcome to the Home Page</h1>
    
    </div>
  );
};

export default Home;
// // import Login from './Components/Navbar/Login'
// function App() {
//  return (
//   <>
//   <Form />  <br />
//   {/* <Login /> */}
//   <TodoInput />
//   </>
//   );
// }

// export default App;